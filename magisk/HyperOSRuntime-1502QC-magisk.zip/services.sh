settings put global force_fsg_nav_bar 1
settings put secure freeform_window_state 0