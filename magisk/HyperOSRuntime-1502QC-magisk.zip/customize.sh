#!/system/bin/sh

#install.sh才需要
#unzip -o "$ZIPFILE" "*" -d "$MODPATH"

# 设置模块安装目录
MODPATH=$MODPATH
ui_print ""
ui_print "正在生成IFW规则（如果系统规则变化需要重新安装，比如系统更新）"
ui_print "MODPATH $MODPATH"
ui_print ""

# 定义源文件和目标文件路径
MIUI_RUNTIME_XML="$MODPATH/system/etc/ifw/miui_runtime.xml"
SYSTEM_IFW_XML="/system/etc/ifw/ifw.xml"
MODULE_IFW_XML="$MODPATH/system/etc/ifw/ifw.xml"


# 函数：合并 XML 文件
merge_xml() {
  local source_xml="$1"
  local target_xml="$2"
  local output_xml="$3"
  {
        # 输出 ifw.xml 的内容，去掉 </rules> 标签
        sed '/<\/rules>/d' "$target_xml"
        # 输出 新增xml 的内容，去掉 <rules> 和 </rules> 标签
        sed -e '1,/<rules>/d' -e '/<\/rules>/d' "$source_xml"
        # 添加 </rules> 标签
        echo "</rules>"
    } > "$output_xml"
}

# 检查 /system/etc/ifw/ifw.xml 是否存在
if [ -f "$SYSTEM_IFW_XML" ]; then
  # 如果存在，合并规则
  ui_print "Merging IFW rules..."
  merge_xml "$MIUI_RUNTIME_XML" "$SYSTEM_IFW_XML" "$MODULE_IFW_XML"

else
  # 如果不存在，复制 miui_runtime.xml
  ui_print "Copying MIUI runtime IFW rules..."
  cp "$MIUI_RUNTIME_XML" "$MODULE_IFW_XML"
fi

# 设置权限 (可选，但推荐)
#chmod 644 "$MODULE_IFW_XML"

ui_print "IFW rules merged/copied successfully!"
ui_print ""
