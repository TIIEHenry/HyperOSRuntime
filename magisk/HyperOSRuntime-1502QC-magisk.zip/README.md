搭配Xposed模块：
https://github.com/TIIEHenry/HyperOSRuntime

模块2：guise伪装机型解锁AI能力
设备填dada